import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import * as moment from 'moment';
import { PostTodayTaskModule, TodayTaskModule } from '../models/todaytask.model';
import { NullTemplateVisitor } from '@angular/compiler';

@Injectable({ providedIn: 'root' })

export class dbTodayTaskServices {
    constructor(private http: HttpClient) { }
    _todayTask: TodayTaskModule; _postTodaytask: PostTodayTaskModule;
    // Http Headers
    httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json'
        })
    }
    async GetTodayTask(USER_ID: number | null, DEALER_ID: number | null) {
        Date.prototype.toJSON = function () {
            return moment(this).format("YYYY-MM-DD");
        }
        this._todayTask = {
            USER_ID: USER_ID,
            DEALER_ID: DEALER_ID
        }

        var body = JSON.stringify(this._todayTask);
        return await this.http.post(environment.apibaseUrl + "Todaytask/GetTodayList", body, this.httpOptions).toPromise
            ().then(
                res => { // Success
                    console.log("Lead Calling Details API Call Success===>");
                    return res;
                },
                msg => { // Error
                    JSON.stringify(msg);
                    console.log(JSON.stringify(msg));
                    console.log("Lead Calling Details API Call Fail==>" + msg["status"] + "---->" + msg["statusText"]);
                    return null;
                }
            );
    }
    async PostTodayTask(_fromValue:any, SalesPersonValue:number|null,StatusValue:number | null,ListValue:any) {
        Date.prototype.toJSON = function () {
            return moment(this).format("YYYY-MM-DD");
        }
        this._postTodaytask = {
            USER_ID: _fromValue["USER_ID"],
            DEALER_ID: _fromValue["DEALER_ID"],
            APPT_ID: ListValue["APPT_ID"],
            CREATED_BY: _fromValue["CREATED_BY"],
            LEADTR_ID: ListValue["LEADTR_ID"],
            LEAD_ID: ListValue["LEAD_ID"],
            REMARKS: null,
            SALESPERSON_ID: SalesPersonValue,
            STATUS_ID: StatusValue
        }

        var body = JSON.stringify(this._postTodaytask);
        return await this.http.post(environment.apibaseUrl + "Todaytask/postTodayTask", body, this.httpOptions).toPromise
            ().then(
                res => { // Success
                    console.log("Lead Calling Details API Call Success===>");
                    return res;
                },
                msg => { // Error
                    console.log("Lead Calling Details API Call Fail==>" + msg["status"] + "---->" + msg["statusText"]);
                    return null;
                }
            );
    }
}
