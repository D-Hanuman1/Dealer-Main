import {Injectable  } from '@angular/core';
import { HttpClient, HttpHeaders,HttpHandler } from '@angular/common/http';
import { DropDowncommon, LeadAppointmentCalling, LeadCalling, LeadCallingdtl, LeadCallingHistorydtl, LeadCallingHistorytrns, NewLead,LeadnotVisitingCalling } from '../models/leadcalling.model';
import * as moment from 'moment';
import { environment } from '@env/environment';

@Injectable({providedIn: 'root'})

export class dbLeadCallingService{
    _dropDownCommon:DropDowncommon;_LeadCallingHistorydtl:LeadCallingHistorydtl;
    _LeadCalling:LeadCalling;_LeadAppointmentCalling:LeadAppointmentCalling;
    _LeadnotVisitingCalling:LeadnotVisitingCalling;
    constructor(private http :HttpClient){}

    // Http Headers
    httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json'
        })
    }
    async GetLeadDetails(LEAD_ID:number | null,Type:string,TypeValue:string,dfromDate:Date | null,dtoDate:Date | null)
    {
        Date.prototype.toJSON=function(){
            return moment(this).format("YYYY-MM-DD");
        }
        this._LeadCalling={
            LEAD_ID:LEAD_ID,
            Type:Type,
            TypeValue:TypeValue,
            dfromDate:dfromDate,
            dtoDate:dtoDate,
        }

        var body=JSON.stringify(this._LeadCalling);
        return await this.http.post(environment.apibaseUrl+"LeadCalling/GetLeadCalling",body,this.httpOptions).toPromise
        ().then(
            res => { // Success
            console.log("Lead Calling Details API Call Success===>");
                return res;
            },
            msg => { // Error
                JSON.stringify(msg);
                console.log(JSON.stringify(msg));
                console.log("Lead Calling Details API Call Fail==>"+msg["status"]+"---->"+msg["statusText"]);
                return null;
            }
          );
    }
    async GetLeadHistoryDetails(LEAD_ID:number,DEALER_ID:number,USER_ID:number)
    {
        Date.prototype.toJSON=function(){
            return moment(this).format("YYYY-MM-DD");
        }
        this._LeadCallingHistorydtl={
            LEAD_ID:LEAD_ID,
            DEALER_ID:DEALER_ID,
            USER_ID:USER_ID
        }
        var body=JSON.stringify(this._LeadCallingHistorydtl);
        return await this.http.post(environment.apibaseUrl+"LeadCalling/GetLeadCallingHistory",body,this.httpOptions).toPromise
        ().then(
            res => { // Success
            console.log("Lead Calling Details API Call Success===>");
                return res;
            },
            msg => { // Error
                JSON.stringify(msg);
                console.log(JSON.stringify(msg));
                console.log("Lead Calling Details API Call Fail==>"+msg["status"]+"---->"+msg["statusText"]);
                return null;
            }
          );
    }
    async PostLeadDetails(obj:LeadCallingdtl)
    {//debugger;
        Date.prototype.toJSON=function(){
            return moment(this).format("YYYY-MM-DD");
        }
        var body=JSON.stringify(obj);
        return await this.http.post(environment.apibaseUrl+"LeadCalling/postLeadCallingdtl",body,this.httpOptions).toPromise
        ().then(
            res => { // Success
              //alert(res);
              //debugger;
            console.log("POST Lead Calling Details API Call Success===>");
                return res;
            },
            msg => { // Error
                JSON.stringify(msg);
                console.log(JSON.stringify(msg));
                console.log(" POST Lead Calling Details API Call Fail==>"+msg["status"]+"---->"+msg["statusText"]);
                return null;
            }
          );
    }
    async PostLeadtrns(obj:LeadCallingHistorytrns)
    {debugger;
        Date.prototype.toJSON=function(){
            return moment(this).format("YYYY-MM-DD");
        }
         //obj.FOLLOWUP_TIME=obj.FOLLOWUP_TIME["hour"]+":"+obj.FOLLOWUP_TIME["minute"]
         //obj.FOLLOWUP_TIME="12:25"
        var body=JSON.stringify(obj);
        return await this.http.post(environment.apibaseUrl+"LeadCalling/postLeadCallingtrns",body,this.httpOptions).toPromise
        ().then(
            res => { // Success
            console.log("POST Lead Calling Details API Call Success===>");
                return res;
            },
            msg => { // Error
                JSON.stringify(msg);
                console.log(JSON.stringify(msg));
                console.log(" POST Lead Calling Details API Call Fail==>"+msg["status"]+"---->"+msg["statusText"]);
                return null;
            }
          );
    }
    async PostNewLead(obj:NewLead)
    {
        Date.prototype.toJSON=function(){
            return moment(this).format("YYYY-MM-DD");
        }
        var body=JSON.stringify(obj);
        return await this.http.post(environment.apibaseUrl+"LeadCalling/postNewLead",body,this.httpOptions).toPromise
        ().then(
            res => { // Success
            console.log("POST Lead Calling Details API Call Success===>");
                return res;
            },
            msg => { // Error
                JSON.stringify(msg);
                console.log(JSON.stringify(msg));
                console.log(" POST Lead Calling Details API Call Fail==>"+msg["status"]+"---->"+msg["statusText"]);
                return null;
            }
          );
    }
    async GetDropDownDetails(type:string,condition:string,DEALER_ID:number)
    {
        this._dropDownCommon={
            Type:type,
            condition:condition,
            DEALER_ID:DEALER_ID
        }
        var body=JSON.stringify(this._dropDownCommon);
        return await this.http.post(environment.apibaseUrl+"DropDown/GetDropDownDtl",body,this.httpOptions).toPromise
        ().then(
            res => { // Success
            console.log("Lead Calling Details API Call Success===>");
                return res;
            },
            msg => { // Error
                JSON.stringify(msg);
                console.log(JSON.stringify(msg));
                console.log("Lead Calling Details API Call Fail==>"+msg["status"]+"---->"+msg["statusText"]);
                return null;
            }
          );
    }

    async GetLeadAppointmentDetails(dfromDate:Date | null,dtoDate:Date | null)
    {
        Date.prototype.toJSON=function(){
            return moment(this).format("YYYY-MM-DD");
        }
        this._LeadAppointmentCalling={
            dfromDate:dfromDate,
            dtoDate:dtoDate,
        }

        var body=JSON.stringify(this._LeadAppointmentCalling);
        return await this.http.post(environment.apibaseUrl+"LeadCalling/GetLeadAppointmentDtl",body,this.httpOptions).toPromise
        ().then(
            res => { // Success
            console.log("Lead Calling Details API Call Success===>");
                return res;
            },
            msg => { // Error
                JSON.stringify(msg);
                console.log(JSON.stringify(msg));
                console.log("Lead Calling Details API Call Fail==>"+msg["status"]+"---->"+msg["statusText"]);
                return null;
            }
          );
    }
    async GetLeadNotVisitingDetails(dfromDate:Date | null,dtoDate:Date | null)
    {
        Date.prototype.toJSON=function(){
            return moment(this).format("YYYY-MM-DD");
        }
        this._LeadnotVisitingCalling={
            dfromDate:dfromDate,
            dtoDate:dtoDate,
        }

        var body=JSON.stringify(this._LeadnotVisitingCalling);
        return await this.http.post(environment.apibaseUrl+"LeadCalling/GetLeadNotVisitingDtl",body,this.httpOptions).toPromise
        ().then(
            res => { // Success
            console.log("Lead Calling Details API Call Success===>");
                return res;
            },
            msg => { // Error
                JSON.stringify(msg);
                console.log(JSON.stringify(msg));
                console.log("Lead Calling Details API Call Fail==>"+msg["status"]+"---->"+msg["statusText"]);
                return null;
            }
          );
    }
    public OnlyNumber(event) {
        const keyCode = event.keyCode;
        const excludedKeys = [8, 37, 39, 46];
        if (!((keyCode >= 48 && keyCode <= 57) ||
          (keyCode >= 96 && keyCode <= 105) ||
          (excludedKeys.includes(keyCode)))) {
          event.preventDefault();
        }
    }
}
