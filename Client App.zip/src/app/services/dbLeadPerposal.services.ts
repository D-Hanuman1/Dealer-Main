import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpHandler } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { DropDowncommon } from '../models/leadcalling.model';
import * as moment from 'moment';
import { VisitModel } from '../models/visitDetail.model';

@Injectable({ providedIn: 'root' })

export class dbPerposalService {

    constructor(private http: HttpClient) { }
    _dropDownCommon: DropDowncommon; _VisitModel: VisitModel;
    // Http Headers
    httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json'
        })
    }
    async GetPerposalDetails(LEAD_ID: number, Dealer_Id: number, Visit_Id: number, Type: string) {
        Date.prototype.toJSON = function () {
            return moment(this).format("YYYY-MM-DD");
        }
        this._VisitModel = {
            DEALER_ID: Dealer_Id,
            LEAD_ID: LEAD_ID,
            TYPE: Type,
            VISIT_ID: Visit_Id
        }

        var body = JSON.stringify(this._VisitModel);
        return await this.http.post(environment.apibaseUrl + "LeadPerposal/GetLeadPerposal", body, this.httpOptions).toPromise
            ().then(
                res => { // Success
                    console.log("Lead Calling Details API Call Success===>");
                    return res;
                },
                msg => { // Error
                    JSON.stringify(msg);
                    console.log(JSON.stringify(msg));
                    console.log("Lead Calling Details API Call Fail==>" + msg["status"] + "---->" + msg["statusText"]);
                    return null;
                }
            );
    }
    async PostPerposal(obj) {
        Date.prototype.toJSON = function () {
            return moment(this).format("YYYY-MM-DD");
        }
        var body = JSON.stringify(obj);
        return await this.http.post(environment.apibaseUrl + "LeadPerposal/PostLeadPerposal", body, this.httpOptions).toPromise
            ().then(
                res => { // Success
                    console.log("POST Lead Calling Details API Call Success===>");
                    return res;
                },
                msg => { // Error
                    JSON.stringify(msg);
                    console.log(JSON.stringify(msg));
                    console.log(" POST Lead Calling Details API Call Fail==>" + msg["status"] + "---->" + msg["statusText"]);
                    return null;
                }
            );
    }
    async GetDropDownDetails(type: string, condition: string, DEALER_ID: number) {
        this._dropDownCommon = {
            Type: type,
            condition: condition,
            DEALER_ID: DEALER_ID
        }
        var body = JSON.stringify(this._dropDownCommon);
        return await this.http.post(environment.apibaseUrl + "DropDown/GetDropDownDtl", body, this.httpOptions).toPromise
            ().then(
                res => { // Success
                    console.log("Lead Calling Details API Call Success===>");
                    return res;
                },
                msg => { // Error
                    JSON.stringify(msg);
                    console.log(JSON.stringify(msg));
                    console.log("Lead Calling Details API Call Fail==>" + msg["status"] + "---->" + msg["statusText"]);
                    return null;
                }
            );
    }
    public OnlyNumber(event) {
        const keyCode = event.keyCode;
        const excludedKeys = [8, 37, 39, 46];
        if (!((keyCode >= 48 && keyCode <= 57) ||
            (keyCode >= 96 && keyCode <= 105) ||
            (excludedKeys.includes(keyCode)))) {
            event.preventDefault();
        }
    }

}
