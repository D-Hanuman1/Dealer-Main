import {Injectable  } from '@angular/core';
import { HttpClient, HttpHeaders,HttpHandler } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Login, LogInLogDtl } from 'app/models/login.model';

@Injectable({providedIn: 'root'})

export class dbLoginService{

    constructor(private http :HttpClient){}

    // Http Headers
    httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json'
        })
    }
    async GetLogin(obj:Login)
    {
        var body=JSON.stringify(obj);
        return await this.http.post(environment.apibaseUrl+"Login/GetLogin",body,this.httpOptions).toPromise
        ().then(
            res => { // Success
            console.log("Login API Call Success===>"+JSON.stringify(res));
                return res;
            },
            msg => { // Error
                JSON.stringify(msg);
                console.log(JSON.stringify(msg));
                console.log("Login API Call Fail==>"+msg["status"]+"---->"+msg["statusText"]);
                return null;
            }
          );
    }
    async GetLogInLogDte(obj:LogInLogDtl)
    {
        var body=JSON.stringify(obj);
        return await this.http.post(environment.baseUrl+"Login/GetLogInLogdtl",body,this.httpOptions).toPromise
        ().then(
            res => { // Success
            console.log("Login API Call Success===>"+JSON.stringify(res));
                return res;
            },
            msg => { // Error
                JSON.stringify(msg);
                console.log(JSON.stringify(msg));
                console.log("Login API Call Fail==>"+msg["status"]+"---->"+msg["statusText"]);
                return null;
            }
          );
    }
}
