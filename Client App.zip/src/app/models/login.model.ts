export interface Login
{
    Username:string;
    Password:string;
}
export interface LogInLogDtl
{
    USER_ID:number;
    DEALER_ID:number;
}