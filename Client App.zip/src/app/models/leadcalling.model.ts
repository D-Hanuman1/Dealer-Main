import { Time } from '@angular/common';

export interface LeadCalling
{
    dfromDate:Date;
    dtoDate:Date;
    LEAD_ID:number;
    Type:string;
    TypeValue:string;
}
export interface LeadAppointmentCalling
{
    dfromDate:Date;
    dtoDate:Date;
}
export interface LeadnotVisitingCalling
{
    dfromDate:Date;
    dtoDate:Date;
}
export interface DropDowncommon
{
    condition:string;
    Type:string;
    DEALER_ID:number;
}
export interface LeadCallingdtl
{
    LEAD_DETAILS_ID:number;
    LEAD_ID:number;
    DEALER_ID:number;
    TITLE:string;
    FIRST_NAME:string;
    LAST_NAME:string;
    MOBILE_NO:string;
    ALTERNATE_MOBILE_NO:string;
    EMAIL_ID:string;
    ENQ_TYPE:string;
    DOB:Date;
    ENQ_REMARKS:string;
    LEAD_PRIORITY:string;
    CLIENT_ADDRESS:string;
    PREFERRED_LAGUAGE:number;
    CLIENT_PINCODE:number;
    CLIENT_CITY:string;
    VEHCHEL_DEMO_REQUIRED:string;
    SHOWROOM_FIELD:string;
    SALES_PERSON:number;
    MAKE_ID:number;
    MODEL_ID:number;
    CREATED_BY:number;
}
export interface LeadCallingHistorydtl
{
    LEAD_ID:number;
    DEALER_ID:number;
    USER_ID:number;
}
export interface LeadCallingHistorytrns
{
    LEAD_ID:number;
    DEALER_ID:number;
    USER_ID:number;
    STATUS_ID:number;
    FOLLOWUP_DATE:Date;
    FOLLOWUP_TIME:string;
    REMARKS:string;
    CREATED_BY:number;
}
export interface NewLead
{
    LEAD_ID:number;
    DEALER_ID:number;
    SOURCE_ID:number;
    PUBLISHER_ID:number;
    CAMPAIGN_id:number;
    LEAD_REMARKS:string;
    LEAD_EMAIL:string;
    LEAD_CITY:number;
    LEAD_NAME:string;
    MOBILE_NO:string;
}
