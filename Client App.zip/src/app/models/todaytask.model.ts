
export interface TodayTaskModule
{
    USER_ID:number;
    DEALER_ID:number;
}
export interface PostTodayTaskModule
{
    USER_ID:number;
    DEALER_ID:number;
    LEAD_ID:number;
    LEADTR_ID:number;
    APPT_ID:number;
    SALESPERSON_ID:number;
    STATUS_ID:number;
    CREATED_BY:number;
    REMARKS:string;
}
