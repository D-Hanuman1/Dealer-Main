

export interface VisitModel
{
    LEAD_ID:number;
    DEALER_ID:number;
    VISIT_ID:number;
    TYPE:string;
}