import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { DialogAddressFormComponent } from 'app/routes/dialog/dialog.component';
import { AppReminderComponent } from './app-calling.component';

const COMPONENTS: any[] = [
  AppReminderComponent,
];
export const routes: Routes = [
  {
      path: '',
      component: AppReminderComponent,
      // data: {
      //     title: 'Dashboard',
      // },
  }
];
const COMPONENTS_DYNAMIC: any[] = [
  //DialogAddressFormComponent,
];
@NgModule({
  imports: [SharedModule,RouterModule.forChild(routes)],
  declarations: [...COMPONENTS,...COMPONENTS_DYNAMIC],
  entryComponents: COMPONENTS_DYNAMIC,
})
export class AppReminderModule {}
