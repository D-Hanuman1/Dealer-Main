import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators,NgForm } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { MtxGridColumn } from '@ng-matero/extensions';
import { DialogAddressFormComponent } from 'app/routes/dialog/dialog.component';
import { dbLeadCallingService } from 'app/services/dbLeadCalling';
import { ToastrService } from 'ngx-toastr';
import { LeadDetailComponent } from '../lead-detail/lead-detail.component';
declare var $:any;
@Component({
  selector: 'app-reminder-calling',
  templateUrl: './app-calling.component.html',
  styleUrls: ['./app-calling.component.css'],
})
export class AppReminderComponent implements OnInit {
  closeResult: string;public current_LeadId:string;
  submitted = false;_dataList:any;_isdataList:boolean=false;
  _Form: FormGroup;isSpinnerVisible: boolean = false;
  columns: MtxGridColumn[] = [
    {
      header: 'Sr. No',
      field: 'srno'
    },
    { header: 'Name', field: 'LEAD_NAME' },
    { header: 'Mobile', field: 'MOBILE_NO' },
    { header: 'Source', field: 'Source_Name', width: '200px' },
    { header: 'Publisher', field: 'PUBLISHER_NAME' },
    { header: 'Campaign', field: 'CAMPAIGN_NAME'},
    { header: 'City', field: 'LEAD_CITY'},
    { header: 'Followup Date', field: 'CREATED_DATE' },
    // {
    //   header: 'Action',
    //   field: 'archived',
    //   type: 'tag',
    //   tag: {
    //     true: { text: 'Yes', color: 'red-100' },
    //     false: { text: 'No', color: 'green-100' },
    //   },
    // },
    {
      header: 'Opertaion',
      field: 'Lead_Id',
      minWidth: 120,
      width: '120px',
      pinned: 'right',
      type: 'button',
      buttons: [
        {
          type: 'icon',
          icon: 'visibility',
          click: record => this.openLeadDetailDialog(record.LEAD_ID),
        },
      ],
    },
  ];
  list: any[] = [];
  total = 0;
  isLoading = false;
  showPaginator = true;
  query = {
    q: 'user:nzbin',
    sort: 'stars',
    order: 'desc',
    page: 0,
    per_page: 10,
  };

  constructor(private fb: FormBuilder,private _dbService:dbLeadCallingService,private toastr: ToastrService,
   private cdr: ChangeDetectorRef,public dialog: MatDialog) { }
  ngOnInit(): void {
    this.isSpinnerVisible=true;
    this.formBuild();
    this.isSpinnerVisible=false;
  }
  formBuild()
  {
    this._Form = this.fb.group({
      dfromDate:[null,Validators.required],
      dtoDate:[null,Validators.required]
    });
  }
  get f() { return this._Form.controls; }

  async onView() {
    this.submitted = true;
    if (this._Form.invalid) {
      return;
    }
    this.isSpinnerVisible=true;
    let data= await this._dbService.GetLeadAppointmentDetails(this._Form.controls["dfromDate"].value,this._Form.controls["dtoDate"].value);
    this._dataList=[];
    JSON.stringify(data);
    console.log(data);
    this._isdataList=true;
    if(data.length !=0){
      //this._dataList=data;
      this.list = data;
      this.total = data.length;
      this.isLoading = false;
      //this.cdr.detectChanges();
    }
    else{
      this.isLoading = false;
      this.cdr.detectChanges();
      // console.log(data["Status"]+'----->'+data["Message"]);
      //this.toastr.error("Unauthorized user / Invalid password",'Login');
    }
    this.isSpinnerVisible=false;
  }
  onSubmit(){

  }


  // getNextPage(e: PageEvent) {
  //   this.query.page = e.pageIndex;
  //   this.query.per_page = e.pageSize;
  //   this.getList();
  // }

  // search() {
  //   this.query.page = 0;
  //   this.getList();
  // }

  // reset() {
  //   this.query.page = 0;
  //   this.query.per_page = 10;
  //   this.getList();
  // }

  openAddressDialog(record:number) {
    this.dialog.open(DialogAddressFormComponent);
  }

  openLeadDetailDialog(LeadId) {
    this.dialog.open(LeadDetailComponent,{
      data: {LeadId:LeadId}
    });
  }
}
