import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { MtxGridColumn } from '@ng-matero/extensions';
// import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { dbLeadCallingService } from 'app/services/dbLeadCalling';
import { dbTodayTaskServices } from 'app/services/dbTodayTask.services';
import { VisiteddetailComponent } from '../lead-app-detail/visiteddetail/visiteddetail.component';
import { ToastrService } from 'ngx-toastr';
declare var $: any;
@Component({
  selector: 'app-todaytask',
  templateUrl: './todaytask.component.html',
  styleUrls: ['./todaytask.component.css']
})

export class TodaytaskComponent implements OnInit {
  closeResult: string; public current_LeadId: string;
  submitted = false; _dataList: any; _isdataList: boolean = false; _StatusList: any;
  _Form: FormGroup; isSpinnerVisible: boolean = false; _SalesManList: any;
  editRowID: any = '';
  dataTable: any; @ViewChild('dataTable') Table: { nativeElement: any; }; dtOptions: any;
  columns: MtxGridColumn[] = [
    { header: 'Sr. No', field: 'srno' },
    { header: 'Client Name', field: 'LEAD_NAME' },
    { header: 'Mobile', field: 'MOBILE_NO' },
    { header: 'EmailId', field: 'LEAD_EMAIL', width: '200px' },
    { header: 'Sale Executive Person', field: 'USER_FIRST_NAME' },
    { header: 'Visit Date and Time', field: 'VISIT_DATE'},
    { header: 'Last Status', field: 'STATUS_NAME'},
    { header: 'Status', field: 'CREATED_DATE' },
    { header: 'Remark', field: 'REMARKS'},
    { header: 'Lead Type', field: 'ENQUIRY_NAME' },
    {
      header: 'Opertaion',
      field: 'leadID',
      type: 'button',
      formatter: (data: any) => `<a href="/todaytaskdtl?leadID=${data.LEAD_ID}&DealerID=${data.DEALER_ID}" target="_blank">Detail</a>`,
      buttons: [
        {
          type: 'icon',
          icon: 'visibility',
          // click: record => this.openLeadDetailDialog(record.LEAD_ID),
        },
        {
          type: 'icon',
          icon: 'visibility',
          // click: record => this.openLeadDetailDialog(record.LEAD_ID),
        },
      ],
    },
  ];
  list: any[] = [];
  total = 0;
  isLoading = false;
  showPaginator = true;
  query = {
    q: 'user:nzbin',
    sort: 'stars',
    order: 'desc',
    page: 0,
    per_page: 10,
  };

  constructor(private fb: FormBuilder, private _dbService: dbTodayTaskServices, public _dbServiceLead: dbLeadCallingService, private toastr: ToastrService,
    public router:Router) { }

  async ngOnInit(): Promise<void> {
    this.isSpinnerVisible = true;
    await this.formBuild();
    await this.onLoad();
    await this.getSalesMan();
    await this.getStatus();
    this.isSpinnerVisible = false;
  }
  Edit(val: { [x: string]: any; }) {
    this.editRowID = val["LEAD_ID"];
    this._Form.controls["SALESPERSON_ID"].setValue(val["SALESPERSON_ID"])
  }
  async onSave(val: any, id: number) {
    //debugger
    var salesId = (document.getElementById("salesPerson_" + id) as HTMLInputElement);
    if (salesId != null) {

      let data = await this._dbService.PostTodayTask(this._Form.value, Number(salesId.value), null, val);

    }
    var statusId = (document.getElementById("status_" + id) as HTMLInputElement);
    if (statusId != null) {
      let data = await this._dbService.PostTodayTask(this._Form.value, null, Number(statusId.value), val);
      this._Form.controls["STATUS_ID"].setValue(null)
    }
    await this.onLoad();
    this.editRowID = '';
  }
  async formBuild() {
    this._Form = this.fb.group({
      USER_ID: [localStorage.getItem("USER_ID")],
      DEALER_ID: [localStorage.getItem("DEALER_ID")],
      CREATED_BY: [localStorage.getItem("USER_ID")],
      SALESPERSON_ID: [null, Validators.required],
      STATUS_ID: [null, Validators.required]
    });
  }
  get f() { return this._Form.controls; }

  async onLoad() {
    this.isSpinnerVisible = true;
    let data = await this._dbService.GetTodayTask(this._Form.controls["USER_ID"].value, this._Form.controls["DEALER_ID"].value);
    this._dataList = [];
    JSON.stringify(data);
    console.log(data);
    this._isdataList = true;
    if (data.length != 0) {
      this._dataList = data;
    }
    else {
      // console.log(data["Status"]+'----->'+data["Message"]);
      //this.toastr.error("Unauthorized user / Invalid password",'Login');
    }
    await this.DataTableBind();
    this.isSpinnerVisible = false;
  }
  onSubmit() {

  }
  async getSalesMan() {
    let data: any = await this._dbServiceLead.GetDropDownDetails("SALESMAN", "", Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      this._SalesManList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getStatus() {
    let data = await this._dbServiceLead.GetDropDownDetails("STATUS_SHOWROOM", "", Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      this._StatusList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async DataTableBind() {
    if ($.fn.DataTable.isDataTable(this.Table.nativeElement)) {
      $(this.Table.nativeElement).dataTable().fnDestroy();
    }
    this.dtOptions = {
      "pagingType": "full",
      "autoWidth": true,
      "bSort": true,
      order: [[0, 'asc']],
    };
    this.dataTable = $(this.Table.nativeElement);
    setTimeout(() => {
      this.dataTable.DataTable(this.dtOptions);
    }, 10);
  }


  async onClickLeaddtl(leadId:any) {
    let newRelativeUrl = this.router.createUrlTree(['todaytaskdtl']);
    let apibaseUrl = window.location.href.replace(this.router.url, '');
    window.open(apibaseUrl + newRelativeUrl, '_blank');
    this.current_LeadId = leadId;
  }


}
