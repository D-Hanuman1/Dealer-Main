import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { TodaytaskComponent } from './todaytask.component';

const COMPONENTS: any[] = [
  TodaytaskComponent
];
export const routes: Routes = [
  {
      path: '',
      component: TodaytaskComponent
  }
];
const COMPONENTS_DYNAMIC: any[] = [
  //DialogAddressFormComponent,
];
@NgModule({
  imports: [SharedModule,RouterModule.forChild(routes)],
  declarations: [...COMPONENTS,...COMPONENTS_DYNAMIC],
  entryComponents: COMPONENTS_DYNAMIC,
})
export class TodayModule {}
