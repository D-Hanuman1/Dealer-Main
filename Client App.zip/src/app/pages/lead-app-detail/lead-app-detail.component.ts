import { Component, Input, OnInit, ViewChild, NgModule } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { dbLeadCallingService } from 'app/services/dbLeadCalling';
import { DatePipe,CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { MatTabChangeEvent } from '@angular/material/tabs';
declare var $: any;

@Component({
  selector: 'leadAppDetail-cmp',
  templateUrl: './lead-app-detail.component.html',
  styleUrls: ['./lead-app-detail.component.css'],
})
export class LeadAppDetailComponent implements OnInit {
  Lead_Id: string; Dealer_ID:string;
  _Form: FormGroup; submitted = false; _FormHistory: FormGroup; _isgettrns: boolean = false;
  _CityList: any = []; _LeadDtl: any = []; _SalesManList: any = [];
  isSpinnerVisible: boolean = false;
  public current_LeadId: string; public current_Dealer: string;
  dataTable: any; @ViewChild('dataTable') Table; dtOptions: any;

  isPersonal: boolean = false; isEnquiry: boolean = false; isVisited: boolean = true;
  isPerposal: boolean = false; isInvoice: boolean = false; isQutation: boolean = false;
  constructor(private fb: FormBuilder, public _dbService: dbLeadCallingService, private toastr: ToastrService,
     private route: ActivatedRoute) { }

     //private modalService: NgbModal,

  async ngOnInit(): Promise<void> {

    this.route.queryParams.subscribe(params => {
      this.Lead_Id = params['leadID'];
      this.Dealer_ID = params['DealerID'];
    });
    this.isSpinnerVisible = true;
    await this.formBuild();
    await this.getLeaddtl(Number(this.Lead_Id));
    this.isSpinnerVisible = false;
  }
  async formBuild() {
    this._Form = this.fb.group({
      LEAD_DETAILS_ID: [null],
      LEAD_ID: [this.Lead_Id],
      DEALER_ID: [this.Dealer_ID],
      ENQ_TYPE: [null],
      CATEGORY_NAME: ['', Validators.required],
      Enq_Status: ['', Validators.required],
      FIRST_NAME: [null],
      MAKE_NAME: [null],
      ENQ_REMARKS: [null],
      MOBILE_NO: [null],
      MODEL_NAME: [null],
      SALES_PERSON_NAME: [null],
      OCCUPATION: [null],
      PRICE_RANGE: [null],
    });
  }
  get f() { return this._Form.controls; }
  async getLeaddtl(LEAD_ID: number) {
    debugger
    let data = await this._dbService.GetLeadDetails(LEAD_ID, "APP_LEADID", "", null, null);
    JSON.stringify(data);
    var datePipe = new DatePipe("en-US");
    if (data != null) {
      for (const field in this._Form.controls) {
        if (data[0][field] != null) {
          this._Form.controls[field].setValue(data[0][field]);
        }
      }
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }

  public tabclick(tabmode) {
    debugger;
    this.isEnquiry = false; this.isPerposal = false; this.isPersonal = false;
    this.isInvoice = false; this.isVisited = false; this.isQutation = false;
    if (tabmode.toLowerCase() == "personal") {
      this.isPersonal = true;
    }
    if (tabmode.toLowerCase() == "enquiry") {
      this.isEnquiry = true;
    }
    if (tabmode.toLowerCase() == "visit details") {
      this.isVisited = true;
    }
    if (tabmode.toLowerCase() == "perposal") {
      this.isPerposal = true;
    }
    if (tabmode.toLowerCase() == "invoice") {
      this.isInvoice = true;
    }
    if (tabmode.toLowerCase() == "qutation details") {
      this.isQutation = true;
    }
  }
}
