import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-viewquot',
  templateUrl: './viewquot.component.html',
  styleUrls: ['./viewquot.component.css']
})
export class ViewquotComponent implements OnInit {
  Lead_Id: string; Dealer_ID:string;
  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.Lead_Id = params['leadID'];
      this.Dealer_ID = params['DealerID'];
    });
  }

}
