import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { LeadAppDetailComponent } from './lead-app-detail.component';
import { ReactiveFormsModule } from '@angular/forms';
import { VisiteddetailComponent } from './visiteddetail/visiteddetail.component';
import { QuotationdetailComponent } from './quotationdetail/quotationdetail.component';
import { PersonaldetailComponent } from './personaldetail/personaldetail.component';
import { PerposaldetailComponent } from './perposaldetail/perposaldetail.component';
import { EnquirydetailComponent } from './enquirydetail/enquirydetail.component';
import { InvoicedetailComponent } from './invoicedetail/invoicedetail.component';
import { VisitvechdltComponent } from './visiteddetail/visitvechdlt/visitvechdlt.component';
import { VisittestdriveComponent } from './visiteddetail/visittestdrive/visittestdrive.component';
import { VisitoverallComponent } from './visiteddetail/visitoverall/visitoverall.component';
import { VisitclientimgComponent } from './visiteddetail/visitclientimg/visitclientimg.component';

const COMPONENTS: any[] = [
  LeadAppDetailComponent,VisiteddetailComponent,QuotationdetailComponent,
  PersonaldetailComponent,PerposaldetailComponent,EnquirydetailComponent,InvoicedetailComponent,
  VisitvechdltComponent,VisittestdriveComponent,VisitoverallComponent,VisitclientimgComponent
];
export const routes: Routes = [
  {
      path: '',
      component: LeadAppDetailComponent,
  }
];
const COMPONENTS_DYNAMIC: any[] = [
  // DialogAddressFormComponent,
];
@NgModule({
  imports: [SharedModule,
    RouterModule.forChild(routes),ReactiveFormsModule],
  declarations: [...COMPONENTS,...COMPONENTS_DYNAMIC],
  entryComponents: COMPONENTS_DYNAMIC,
})
export class LeadAppDetailModule {}
