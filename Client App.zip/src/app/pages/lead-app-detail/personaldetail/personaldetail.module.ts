import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { PersonaldetailComponent } from './personaldetail.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
const COMPONENTS: any[] = [
  //PersonaldetailComponent,
];
const COMPONENTS_DYNAMIC: any[] = [
  // DialogAddressFormComponent,
];
@NgModule({
  imports: [SharedModule,ReactiveFormsModule],
  declarations: [...COMPONENTS,...COMPONENTS_DYNAMIC],
  entryComponents: COMPONENTS_DYNAMIC,
})
export class PersonaldetailModule {}
