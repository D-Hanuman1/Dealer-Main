import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personaldetail',
  templateUrl: './personaldetail.component.html',
  styleUrls: ['./personaldetail.component.css']
})
export class PersonaldetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

