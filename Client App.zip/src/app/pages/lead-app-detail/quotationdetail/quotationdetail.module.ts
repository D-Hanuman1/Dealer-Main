import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { QuotationdetailComponent } from './quotationdetail.component';
//import { DialogAddressFormComponent } from 'app/routes/dialog/dialog.component';

const COMPONENTS: any[] = [
  //QuotationdetailComponent,
];
const COMPONENTS_DYNAMIC: any[] = [
  // DialogAddressFormComponent,
];
@NgModule({
  imports: [SharedModule],
  declarations: [...COMPONENTS,...COMPONENTS_DYNAMIC],
  entryComponents: COMPONENTS_DYNAMIC,
})
export class QuotationdetailModule {}
