import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
// import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute } from '@angular/router';
import { dbVisitService } from 'app/services/dbVisit.services';
import { MtxGridColumn } from '@ng-matero/extensions';
// import { dbVisitService } from 'src/app/services/dbVisit.services';
declare var $: any;

@Component({
  selector: 'app-visittestdrive',
  templateUrl: './visittestdrive.component.html',
  styleUrls: ['./visittestdrive.component.css'],
})
export class VisittestdriveComponent implements OnInit {
  @Input() Lead_Id: string; @Input() Dealer_Id: string;// decorate the property with @Input()
  _Form: FormGroup; submitted = false;public PageMode:string;
  _ModelList: any = []; isSpinnerVisible: boolean = false;
  _isdataList: boolean = false; _dataList: any = [];

  dataTable:any;@ViewChild('dataTable') Table: { nativeElement: any; }; dtOptions: any;
  columns: MtxGridColumn[] = [
    { header: 'Edit', field: 'Edit' },
    { header: 'Vehical Model', field: 'MODEL_NAME' },
    { header: 'Remarks', field: 'VEHICAL_VISIT_REMARK' },
    { header: 'Test derive', field: 'TEST_DRIVER' },
    { header: 'Vehicle no', field: 'VEHICLE_NO' },
    { header: 'Test derive Assistant details', field: 'TEST_DRIVE_ASSISTANT_DETAILS' },
  ];
  list: any[] = [];
  total = 0;
  isLoading = false;
  showPaginator = true;
  query = {
    q: 'user:nzbin',
    sort: 'stars',
    order: 'desc',
    page: 0,
    per_page: 10,
  };

  constructor(private fb: FormBuilder, public _dbService: dbVisitService, public toastr: ToastrService,
     private route: ActivatedRoute) { }

  async ngOnInit(): Promise<void> {
    this.isSpinnerVisible = true;
    await this.formBuild();
    await this.pageLoad();
    await this.getModel();
    await this.getLeaddtl(Number(this.Lead_Id), Number(this.Dealer_Id));

    this.isSpinnerVisible = false;
  }


  async formBuild() {
    this._Form = this.fb.group({
      VISIT_ID: [null],
      LEAD_ID: [this.Lead_Id],
      DEALER_ID: [this.Dealer_Id],
      MODEL_ID: [null],
      MODEL_NAME:[null],
      TEST_DRIVER: [null],
      VEHICLE_NO: [''],
      TEST_DRIVE_ASSISTANT_DETAILS: [''],
      CREATED_BY: [null],
      MODIFY_BY: [null],
      TYPE: ['VEHICAL_TEST']
    });
  }
  get f() { return this._Form.controls; }
  async pageLoad() {
    this._Form.controls["CREATED_BY"].setValue(localStorage.getItem("USER_ID"))
    this._Form.controls["MODIFY_BY"].setValue(localStorage.getItem("USER_ID"))
  }
  async getLeaddtl(LEAD_ID: number, Dealer_Id: number) {
    debugger;
    this.isSpinnerVisible = true;
    let data = await this._dbService.GetVisitDetails(LEAD_ID, Dealer_Id, null, "LeadID");
    this._dataList = [];
    JSON.stringify(data);
    console.log(data);
    this._isdataList = true;
    if (data.length != 0) {
      this._dataList = data;
      this._isdataList = true;
    }
    else {
      this._isdataList = false;
      // console.log(data["Status"]+'----->'+data["Message"]);
      //this.toastr.error("Unauthorized user / Invalid password",'Login');
    }
    await this.DataTableBind();
    this.isSpinnerVisible = false;
  }
  async getModel() {
    let data = await this._dbService.GetDropDownDetails("VISIT_VEHICAL_MODEL", this.Lead_Id, Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      this._ModelList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }

  public async onSubmit() {
    this.submitted = true;
    if (this._Form.invalid) {
      return;
    }
    try {
      let data = await this._dbService.PostVisitVehicalTest(this._Form.value);
      JSON.stringify(data);
      if (data != null) {
        this._Form.controls["VISIT_ID"].setValue(data);
        this.toastr.success("Lead details updated successfully!", 'Lead Details');
        await this.getLeaddtl(this._Form.controls["LEAD_ID"].value, this._Form.controls["DEALER_ID"].value)
      }
      else {
        this.toastr.error("Lead details not updated successfully!", 'Lead Details');
      }
    }
    catch (error) {

    }
    this.PageMode="ADD";
  }
  public async onReset() {
    this.submitted = false;
    this.PageMode="ADD";
  }
  async onCloseModal() {
    // this.modalService.dismissAll();
  }
  onEdit(data: any, Mode: string) {
    this.PageMode=Mode;
    for (let i in this._Form.controls) {
      if(i!="CREATED_BY" && i!="MODIFY_BY" && i!="TYPE"){
      this._Form.controls[i].setValue(data[i]);
      }
    }
  }
  async DataTableBind() {
    if ($.fn.DataTable.isDataTable(this.Table.nativeElement)) {
      $(this.Table.nativeElement).dataTable().fnDestroy();
    }
    this.dtOptions = {
      "pagingType": "full",
      "autoWidth": true,
      "bSort": true,
      "paging": false,
      "info": false,
      "ordering": false,
      "searching": false
    };
    this.dataTable = $(this.Table.nativeElement);
    setTimeout(() => {
      this.dataTable.DataTable(this.dtOptions);
    }, 10);
  }
}



