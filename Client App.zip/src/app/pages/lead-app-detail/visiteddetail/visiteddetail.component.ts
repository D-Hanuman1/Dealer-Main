import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { DatePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { dbLeadCallingService } from 'app/services/dbLeadCalling';
declare var $: any;

@Component({
  selector: 'app-visiteddetail',
  templateUrl: './visiteddetail.component.html',
  styleUrls: ['./visiteddetail.component.css'],
})
export class VisiteddetailComponent implements OnInit {
  @Input() Lead_Id: string; @Input() Dealer_Id: string;  // decorate the property with @Input()
  public isSpinnerVisible: boolean = false; _Form: FormGroup;
  isVisitclientImg: boolean = false; isVisitVechicalDtl: boolean = true; isVisitTestDrive: boolean = false;
  isVisitOverall: boolean = false;
  constructor(private fb: FormBuilder, public _dbService: dbLeadCallingService, private toastr: ToastrService,
    private route: ActivatedRoute) { }

  async ngOnInit(): Promise<void> {
    this.isSpinnerVisible = true;
    await this.formBuild();
    this.isSpinnerVisible = false;
  }


  async formBuild() {
    this._Form = this.fb.group({
      LEAD_ID: [this.Lead_Id],
      DEALER_ID: [this.Dealer_Id]
    });
  }
  get f() { return this._Form.controls; }

  public tabclick(tabmode: string) {
    debugger;
    this.isVisitclientImg = false; this.isVisitVechicalDtl = false; this.isVisitTestDrive = false;
    this.isVisitOverall = false;
    if (tabmode == "Vehicle details") {
      this.isVisitVechicalDtl = true;
    }
    if (tabmode == "Test Drive Facility") {
      this.isVisitTestDrive = true;
    }
    if (tabmode == "Client Image") {
      this.isVisitclientImg = true;
    }
    if (tabmode == "Overall Remarks") {
      this.isVisitOverall = true;
    }
  }
}


