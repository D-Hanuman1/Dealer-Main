
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enquirydetail',
  templateUrl: './enquirydetail.component.html',
  styleUrls: ['./enquirydetail.component.css']
})
export class EnquirydetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

