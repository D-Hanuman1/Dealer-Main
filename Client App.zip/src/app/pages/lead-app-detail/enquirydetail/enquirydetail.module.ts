import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { EnquirydetailComponent } from './enquirydetail.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const COMPONENTS: any[] = [
  //EnquirydetailComponent,
];
const COMPONENTS_DYNAMIC: any[] = [
  // DialogAddressFormComponent,
];
@NgModule({
  imports: [SharedModule,ReactiveFormsModule],
  declarations: [...COMPONENTS,...COMPONENTS_DYNAMIC],
  entryComponents: COMPONENTS_DYNAMIC,
})
export class EnquirydetailModule {}
