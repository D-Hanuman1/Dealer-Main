import { Component, Input, OnInit, NgModule } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule  } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { dbLeadCallingService } from 'app/services/dbLeadCalling';
//declare var $:any;
@Component({
  selector: 'app-invoicedetail',
  templateUrl: './invoicedetail.component.html',
  styleUrls: ['./invoicedetail.component.css']
})

export class InvoicedetailComponent implements OnInit {
  @Input() Lead_Id: string; @Input() Dealer_Id: string;
  _Form: FormGroup; submitted = false;
  _CategoryList:any=[];_CampaignList:any=[];_ModelList:any[];_MakeList:any[];_ColorList:any[];
  constructor(private fb: FormBuilder, public _dbService: dbLeadCallingService,private toastr: ToastrService) { }

  async ngOnInit(): Promise<void> {
    this.formBuild();
    await this.pageLoad();
    await this.getMake();
    await this.getColor();
    await this.getCategory();
  }
  async formBuild() {
    this._Form = this.fb.group({
      LEAD_ID: [this.Lead_Id],
      DEALER_ID: [this.Dealer_Id],
      QUTATION_ID: [null],
      FULL_NAME: [''],
      CATEGORY_ID: [''],
      MANUFACTURER: [''],
      MOBILE_NO: [''],
      MAKE_ID: [''],
      MODEL_ID: [''],
      COLOR_ID: [''],
      EMAIL_ID: [''],
      FUEL_TYPE: [''],
      ADDRESS: [''],
      CLASS: [''],
      MILEAGE: [''],
      PINCODE: [''],
      WEIGHT: [''],
      SHOW_ROOM_PRICE: [''],
      ACCESSORIES: [''],
      DISCOUNT: [''],
      FINAL_PRICE: [''],
      TAX_DETAIL: [''],
      CREATED_BY: [null],
      MODIFY_BY: [null]
    })
  }
  get f() { return this._Form.controls; }
  async pageLoad(){
    this._Form.controls["DEALER_ID"].setValue(localStorage.getItem("DEALER_ID"))
    this._Form.controls["CREATED_BY"].setValue(localStorage.getItem("USER_ID"))
    this._Form.controls["MODIFY_BY"].setValue(localStorage.getItem("USER_ID"))
  }
  async getMake() {
    let data = await this._dbService.GetDropDownDetails("MAKE", "",Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      this._MakeList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getCategory() {
    let data = await this._dbService.GetDropDownDetails("CATEGORY", "",Number(localStorage.getItem("DEALER_ID"))  );
    JSON.stringify(data);
    if (data != null) {
      debugger;
      this._CategoryList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getModel(MakeId :number,type:string) {
    let data = await this._dbService.GetDropDownDetails("MODEL", "MAKE_ID="+MakeId,Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      if(type=="NEW"){
        this._ModelList = data;
      }
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getColor() {
    //let MakeId=this._Form.controls["MAKE_ID"].value;
    let data = await this._dbService.GetDropDownDetails("COLOR", null,Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
        this._ColorList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  public async onSubmit() {
    debugger;
    this.submitted = true;
    if (this._Form.invalid) {
      return;
    }
    try {
      let data = await this._dbService.PostNewLead(this._Form.value);
      JSON.stringify(data);
      if (data != null) {
        this.toastr.success("Lead created successfully!",'New Lead');
        this.onReset();
      }
      else {
        this.toastr.error("Lead not created successfully!",'New Lead');
      }
    }
    catch(error){

    }
  }
  public async onReset(){
    this.submitted = false;
    this._Form.reset();
  }

}
