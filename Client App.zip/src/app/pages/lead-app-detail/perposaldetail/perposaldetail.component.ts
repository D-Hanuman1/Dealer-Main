import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { dbPerposalService } from 'app/services/dbLeadPerposal.services';
import { ToastrService } from 'ngx-toastr'

@Component({
  selector: 'app-perposaldetail',
  templateUrl: './perposaldetail.component.html',
  styleUrls: ['./perposaldetail.component.css']
})
export class PerposaldetailComponent implements OnInit {
  @Input() Lead_Id: string; @Input() Dealer_Id: string;
  _Form: FormGroup; submitted = false;
  _CategoryList:any=[];_CampaignList:any=[];_ModelList:any[];_MakeList:any[];_ColorList:any[];
  constructor(private fb: FormBuilder, public _dbService: dbPerposalService,private toastr: ToastrService) { }

  async ngOnInit(): Promise<void> {
    this.formBuild();
    await this.pageLoad();
    await this.getMake();
    await this.getColor();
    await this.getCategory();
    await this.getLeaddtl(Number(this.Lead_Id),Number(this.Dealer_Id));
  }
  async formBuild() {
    this._Form = this.fb.group({
      LEAD_ID: [this.Lead_Id],
      DEALER_ID: [this.Dealer_Id],
      QUTATION_ID: [null],
      FULL_NAME: [''],
      CATEGORY_ID: [''],
      MANUFACTURER: [''],
      MOBILE_NO: [''],
      MAKE_ID: [''],
      MODEL_ID: [''],
      COLOR_ID: [''],
      EMAIL_ID: [''],
      FUEL_TYPE: [''],
      ADDRESS: [''],
      CLASS: [''],
      MILEAGE: [''],
      PINCODE: [''],
      WEIGHT: [''],
      SHOW_ROOM_PRICE: [''],
      ACCESSORIES: [''],
      DISCOUNT: [''],
      FINAL_PRICE: [''],
      TAX_DETAIL: [''],
      CREATED_BY: [null],
      MODIFY_BY: [null]
    })
  }
  get f() { return this._Form.controls; }
  async pageLoad(){
    this._Form.controls["DEALER_ID"].setValue(localStorage.getItem("DEALER_ID"))
    this._Form.controls["CREATED_BY"].setValue(localStorage.getItem("USER_ID"))
    this._Form.controls["MODIFY_BY"].setValue(localStorage.getItem("USER_ID"))
  }
  async getMake() {
    let data = await this._dbService.GetDropDownDetails("MAKE", "",Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      this._MakeList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getCategory() {
    let data = await this._dbService.GetDropDownDetails("CATEGORY", "",Number(localStorage.getItem("DEALER_ID"))  );
    JSON.stringify(data);
    if (data != null) {
      debugger;
      this._CategoryList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getModel(MakeId :number,type:string) {
    let data = await this._dbService.GetDropDownDetails("MODEL", "MAKE_ID="+MakeId,Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      if(type=="NEW"){
        this._ModelList = data;
      }
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getColor() {
    //let MakeId=this._Form.controls["MAKE_ID"].value;
    let data = await this._dbService.GetDropDownDetails("COLOR", null,Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
        this._ColorList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  public async onSubmit() {
    debugger;
    this.submitted = true;
    if (this._Form.invalid) {
      return;
    }
    try {
      let data = await this._dbService.PostPerposal(this._Form.value);
      JSON.stringify(data);
      if (data != null) {
        this.toastr.success("Lead Perposal updated successfully!",'Lead Perposal');
        //this.onReset();
      }
      else {
        this.toastr.error("Lead Perposal not updated successfully!",'Lead Perposal');
      }
    }
    catch(error){

    }
  }
  public async onReset(){
    this.submitted = false;
    this._Form.reset();
  }
  async getLeaddtl(LEAD_ID: number,Dealer_Id:number) {
    let data = await this._dbService.GetPerposalDetails(LEAD_ID, Dealer_Id, null, null);
    JSON.stringify(data);
    if (data != null) {
      for (const field in this._Form.controls) {
        if (data[0][field] != null && field!="MODEL_ID") {
          this._Form.controls[field].setValue(data[0][field]);
        }
        if(field=="MODEL_ID"){
          if(data[0]["MAKE_ID"]!=null){
          this.getModel(data[0]["MAKE_ID"],"NEW")
          }
          if(data[0]["MODEL_ID"]==null){
            this._Form.controls[field].setValue('');
          }
          else{
            this._Form.controls[field].setValue(data[0]["MODEL_ID"]);
          }
        }
      }

    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }

}
