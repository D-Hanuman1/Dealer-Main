import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { DialogAddressFormComponent } from 'app/routes/dialog/dialog.component';
import { AdvSearchComponent } from './advsearch.component';
import { LeadDetailComponent } from '../lead-detail/lead-detail.component';
import { NewLeadComponent } from 'app/routes/new-lead/new-lead.component';
import { LeadcallingtrnsComponent } from '../leadcallingtrns/leadcallingtrns.component';

const COMPONENTS: any[] = [
  AdvSearchComponent,
];
export const routes: Routes = [
  {
      path: '',
      component: AdvSearchComponent,
      // data: {
      //     title: 'Dashboard',
      // },
  }
];
const COMPONENTS_DYNAMIC: any[] = [
  LeadDetailComponent ,NewLeadComponent,LeadcallingtrnsComponent
];
@NgModule({
  imports: [SharedModule,RouterModule.forChild(routes)],
  declarations: [...COMPONENTS,...COMPONENTS_DYNAMIC],
  entryComponents: COMPONENTS_DYNAMIC,
})
export class AdvSearchModule {}
