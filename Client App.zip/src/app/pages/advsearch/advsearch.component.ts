import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators,NgForm } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MtxGridColumn } from '@ng-matero/extensions';
import { NewLeadComponent } from 'app/routes/new-lead/new-lead.component';
import { dbLeadCallingService } from 'app/services/dbLeadCalling';
import { ToastrService } from 'ngx-toastr';
import { LeadDetailComponent } from '../lead-detail/lead-detail.component';

@Component({
  selector: 'app-adv-search',
  templateUrl: './advsearch.component.html',
  styleUrls: ['./advsearch.component.css'],
})
export class AdvSearchComponent implements OnInit {
  closeResult: string;public current_LeadId:string;
  submitted = false;_dataList:any;_isdataList:boolean=false;
  _Form: FormGroup;isSpinnerVisible: boolean = false;
  columns: MtxGridColumn[] = [
    {
      header: 'Sr. No',
      field: 'srno'
    },
    { header: 'Name', field: 'LEAD_NAME' },
    { header: 'Mobile', field: 'MOBILE_NO' },
    { header: 'Source', field: 'Source_Name', width: '200px' },
    { header: 'Publisher', field: 'PUBLISHER_NAME' },
    { header: 'Campaign', field: 'CAMPAIGN_NAME'},
    { header: 'City', field: 'LEAD_CITY'},
    { header: 'Followup Date', field: 'CREATED_DATE' },
    // {
    //   header: 'Action',
    //   field: 'archived',
    //   type: 'tag',
    //   tag: {
    //     true: { text: 'Yes', color: 'red-100' },
    //     false: { text: 'No', color: 'green-100' },
    //   },
    // },
    {
      header: 'Opertaion',
      field: 'LEAD_ID',
      type: 'button',
      buttons: [
        {
          type: 'icon',
          icon: 'visibility',
          click: record => this.openLeadDetailDialog(record.LEAD_ID),
        },
      ],
    },
  ];
  list: any[] = [];
  total = 0;
  isLoading = false;
  showPaginator = true;
  query = {
    q: 'user:nzbin',
    sort: 'stars',
    order: 'desc',
    page: 0,
    per_page: 10,
  };

  constructor(private fb: FormBuilder,private _dbService:dbLeadCallingService,private toastr: ToastrService,
   private cdr: ChangeDetectorRef,public dialog: MatDialog) { }
  ngOnInit(): void {
    this.isSpinnerVisible=true;
    this.formBuild();
    this.isSpinnerVisible=false;
  }
  formBuild()
  {
    this._Form = this.fb.group({
      SearchType:['',Validators.required],
      SearchValue:[null,Validators.required]
    });
  }
  get f() { return this._Form.controls; }

  async onSubmit() {
    this.submitted = true;
    if (this._Form.invalid) {
      return;
    }
    this.isSpinnerVisible=true;
    let data= await this._dbService.GetLeadDetails(null,this._Form.controls["SearchType"].value,this._Form.controls["SearchValue"].value,null,null);
    this._dataList=[];
    JSON.stringify(data);
    console.log(data);
    this._isdataList=true;
    if(data.length !=0){
      //this._dataList=data;
      this.list = data;
      this.total = data.length;
      this.isLoading = false;
      //this.cdr.detectChanges();
    }
    else{
      this.isLoading = false;
      this._isdataList=false;
      this.openNewLeadDialog();
    }
    this.isSpinnerVisible=false;
  }
  openNewLeadDialog() {
    this.dialog.open(NewLeadComponent,{
      data: {SearchType:this._Form.controls["SearchType"].value, SearchValue: this._Form.controls["SearchValue"].value},
    });
  }


  openLeadDetailDialog(LeadId) {
    this.dialog.open(LeadDetailComponent,{
      data: {LeadId:LeadId}
    });
  }
}
