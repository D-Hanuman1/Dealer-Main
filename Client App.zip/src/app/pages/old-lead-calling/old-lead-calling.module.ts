import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { DialogAddressFormComponent } from 'app/routes/dialog/dialog.component';
import { OldLeadComponent } from './old-lead-calling.component';

const COMPONENTS: any[] = [
  OldLeadComponent,
];
export const routes: Routes = [
  {
      path: '',
      component: OldLeadComponent,
      // data: {
      //     title: 'Dashboard',
      // },
  }
];
const COMPONENTS_DYNAMIC: any[] = [
  //DialogAddressFormComponent,
];
@NgModule({
  imports: [SharedModule,RouterModule.forChild(routes)],
  declarations: [...COMPONENTS,...COMPONENTS_DYNAMIC],
  entryComponents: COMPONENTS_DYNAMIC,
})
export class OldLeadModule {}
