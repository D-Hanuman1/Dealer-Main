import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { dbLeadCallingService } from 'app/services/dbLeadCalling';
import { ToastrService } from 'ngx-toastr';
import { DateAdapter } from '@angular/material/core';

import { MtxDatetimepickerFilterType, MtxGridColumn } from '@ng-matero/extensions';
import * as moment from 'moment';

import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';

declare var $:any;

@Component({
  selector: 'app-leadcallingtrns',
  templateUrl: './leadcallingtrns.component.html',
  styleUrls: ['./leadcallingtrns.component.css']
})
export class LeadcallingtrnsComponent implements OnInit {
  @Input() Lead_Id: string;@Input() Dealer_Id: string;
  _LeadDtl: any = [];isLeadDtl:boolean=false;
  _leadHistoryList:any=[];_StatusList:any=[];
  dataTable:any;@ViewChild('dataTable') Table;dtOptions: any;
  closeResult: string;public current_LeadId:string;
  submitted = false;_dataList:any;_isdataList:boolean=false;
  _Form1: FormGroup;isSpinnerVisible: boolean = false;
  columns: MtxGridColumn[] = [
    { header: 'Call Date & Call By', field: 'CALLDATE_CALLBY' },
    { header: 'Status', field: 'STATUS_NAME' },
    { header: 'Follow-up Date', field: 'FOLLOWUP_DATE' },
    { header: 'Remarks', field: 'REMARKS', width: '200px' },
  ];
  list: any[] = [];
  total = 0;
  isLoading = false;
  showPaginator = true;
  query = {
    q: 'user:nzbin',
    sort: 'stars',
    order: 'desc',
    page: 0,
    per_page: 10,
  };

  type = 'moment';
  group: FormGroup;
  today: moment.Moment;
  tomorrow: moment.Moment;
  min: moment.Moment;
  max: moment.Moment;
  start: moment.Moment;
  filter: (date: moment.Moment | null, type: MtxDatetimepickerFilterType) => boolean;

  translateSubscription!: Subscription;

  constructor(private fb: FormBuilder, private _dbService: dbLeadCallingService,private toastr: ToastrService,
    private dateAdapter: DateAdapter<any>,
    private translate: TranslateService
  ) {
    this.today = moment.utc();
    this.tomorrow = moment.utc().date(moment.utc().date() + 1);
    this.min = this.today.clone().year(2018).month(10).date(3).hour(11).minute(10);
    this.max = this.min.clone().date(4).minute(45);
    this.start = this.today.clone().year(1930).month(9).date(28);
    this.filter = (date: moment.Moment | null, type: MtxDatetimepickerFilterType) => {
      if (date === null) {
        return true;
      }
      switch (type) {
        case MtxDatetimepickerFilterType.DATE:
          return date.year() % 2 === 0 && date.month() % 2 === 0 && date.date() % 2 === 0;
        case MtxDatetimepickerFilterType.HOUR:
          return date.hour() % 2 === 0;
        case MtxDatetimepickerFilterType.MINUTE:
          return date.minute() % 2 === 0;
      }
    };

    this.group = fb.group({
      dateTime: [new Date('2017-11-09T12:10:00.000Z'), Validators.required],
      dateTimeYear: [new Date('2017-11-09T12:10:00.000Z'), Validators.required],
      date: [null, Validators.required],
      time: [null, Validators.required],
      timeAMPM: [null, Validators.required],
      month: [null, Validators.required],
      year: [null, Validators.required],
      mintest: [this.today, Validators.required],
      filtertest: [this.today, Validators.required],
      touch: [null, Validators.required],
    });
 }

  //private options: string[] = ['10', '20', '50'];
  public newTime:string='13:30';
  time = {hour: 13, minute: 30};

  ngOnInit(): void {
    this.formBuild();
    this.pageLoad();
    this.getStatus();
    this.onLeadHistory(Number(this.Lead_Id),Number(this.Dealer_Id),Number(localStorage.getItem("USER_ID")));
    this.translateSubscription = this.translate.onLangChange.subscribe((res: { lang: any }) => {
      this.dateAdapter.setLocale(res.lang);
    });
  }
  async formBuild() {
    this._Form1 = this.fb.group({
      LEAD_DETAILS_ID: [null],
      LEAD_ID: [this.Lead_Id],
      DEALER_ID: [this.Dealer_Id],
      STATUS_ID: ['',Validators.required],
      FOLLOWUP_DATE: ['',Validators.required],
      FOLLOWUP_TIME: [this.time,Validators.required],
      REMARKS: ['',Validators.required],
      CREATED_BY: [null],
      USER_ID: [null]
    })
  }
  get f() { return this._Form1.controls; }
  async pageLoad(){
    this._Form1.controls["CREATED_BY"].setValue(localStorage.getItem("USER_ID"));
    this._Form1.controls["USER_ID"].setValue(localStorage.getItem("USER_ID"))
  }
  async getStatus() {
    let data = await this._dbService.GetDropDownDetails("STATUS", "",Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      this._StatusList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  public async onHistorySubmit() {
    // debugger;
    this.submitted = true;
    if (this._Form1.invalid) {
      return;
    }
    try {
      let data = await this._dbService.PostLeadtrns(this._Form1.value);debugger;
      JSON.stringify(data);
      if (data != null) {
        this.onLeadHistory(Number(this.Lead_Id),Number(this.Dealer_Id),Number(localStorage.getItem("USER_ID")))
        this.toastr.error("Lead details Transaction not updated successfully!",'Lead Details Transaction');
      }
      else {
        this.toastr.success("Lead details Transaction updated successfully!",'Lead Details Transaction');

      }
    }
    catch(error){

    }
  }
  public async onHistoryReset(){
    this.submitted = false;
  }
  async onLeadHistory(LEAD_ID:number,DEALER_ID:number,USER_ID:number) {
    let data= await this._dbService.GetLeadHistoryDetails(LEAD_ID,DEALER_ID,USER_ID);
    this._leadHistoryList=[];
    JSON.stringify(data);
    if(data.length !=0){
      // debugger;
      this._leadHistoryList=data;
      //debugger;
    }
    // this.DataTableBind();
  }
  // DataTableBind(){
  //   if ($.fn.DataTable.isDataTable(this.Table.nativeElement) ) {
  //     $(this.Table.nativeElement).dataTable().fnDestroy();
  //   }
  //   this.dtOptions = {
  //     "pagingType": "full",
  //     "autoWidth": true,
  //     "bSort" : false,
  //     order: [[3, 'asc']],
  //   };
  //   this.dataTable = $(this.Table.nativeElement);
  //   setTimeout(()=>{
  //     this.dataTable.DataTable(this.dtOptions);
  //   }, 10  );
  // }
  onTimeChange(value:{hour:string,minute:string})
  {
    console.log(value)
    this.newTime=`${value.hour}:${value.minute}`;
    console.log(this.newTime)
  }

}
