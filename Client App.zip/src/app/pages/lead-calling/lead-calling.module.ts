import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { LeadcallingComponent } from './lead-calling.component';
import { DialogAddressFormComponent } from 'app/routes/dialog/dialog.component';

const COMPONENTS: any[] = [
  LeadcallingComponent,
];
export const routes: Routes = [
  {
      path: '',
      component: LeadcallingComponent,
      // data: {
      //     title: 'Dashboard',
      // },
  }
];
const COMPONENTS_DYNAMIC: any[] = [
  DialogAddressFormComponent,
];
@NgModule({
  imports: [SharedModule,RouterModule.forChild(routes)],
  declarations: [...COMPONENTS,...COMPONENTS_DYNAMIC],
  entryComponents: COMPONENTS_DYNAMIC,
})
export class LeadCallingModule {}
