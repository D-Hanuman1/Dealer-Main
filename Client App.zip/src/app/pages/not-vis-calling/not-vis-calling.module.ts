import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { NotVisitedCallingComponent } from './not-vis-calling.component';
//import { DialogAddressFormComponent } from 'app/routes/dialog/dialog.component';

const COMPONENTS: any[] = [
  NotVisitedCallingComponent,
];
export const routes: Routes = [
  {
      path: '',
      component: NotVisitedCallingComponent,
      // data: {
      //     title: 'Dashboard',
      // },
  }
];
const COMPONENTS_DYNAMIC: any[] = [
  // DialogAddressFormComponent,
];
@NgModule({
  imports: [SharedModule,RouterModule.forChild(routes)],
  declarations: [...COMPONENTS,...COMPONENTS_DYNAMIC],
  entryComponents: COMPONENTS_DYNAMIC,
})
export class NotVisitedModule {}
