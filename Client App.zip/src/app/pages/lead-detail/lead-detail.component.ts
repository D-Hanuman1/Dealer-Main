import { Component, Inject, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { dbLeadCallingService } from 'app/services/dbLeadCalling';
import { DatePipe } from '@angular/common';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { LeadcallingtrnsComponent } from '../leadcallingtrns/leadcallingtrns.component';
//import { NgbModal } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-lead-detail',
  templateUrl: './lead-detail.component.html',
  styleUrls: ['./lead-detail.component.css']
})
export class LeadDetailComponent implements OnInit {
  _Form: FormGroup; submitted = false;_FormHistory: FormGroup;_isgettrns:boolean=false;
  _EnquiryStatusList: any = []; _LeadDtl: any = [];_SalesManList: any = [];_CampaignList:any=[];_CategoryList:any=[];
  _LanguageList: any = [];_TitleList: any = [];_ShowroomList: any = [];_MakeList: any = [];_ModelList: any = [];
  _OLD_MakeList: any = [];_OLD_ModelList: any = [];
  _leadHistoryList:any=[];_StatusList:any=[];isSpinnerVisible: boolean = false;
  public current_LeadId:string;public current_Dealer:string;
  dataTable:any;@ViewChild('dataTable') Table;dtOptions: any;
  public MobileNo: any; public LeadName: any; public LeadDateTime: any; public LeadCode: any;
  constructor(private fb: FormBuilder, public _dbService: dbLeadCallingService,private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public LeadInfo: {LeadId: number}) { }

  //private options: string[] = ['10', '20', '50'];
  time = {hour: 10, minute: 30};
  async ngOnInit(): Promise<void> {
    this.isSpinnerVisible=true;
    await this.formBuild();
    await this.pageLoad();
    await this.getEnquiryStatus();
    await this.getCampaign();
    await this.getSalesMan();
    await this.getTitle();
    await this.getLanguage();
    await this.getMake();
    await this.getCategory();
    await this.getLeaddtl(Number(this.LeadInfo.LeadId));
    this.isSpinnerVisible=false;
  }


  async formBuild() {
    this._Form = this.fb.group({
      LEAD_DETAILS_ID: [null],
      LEAD_ID: [this.LeadInfo.LeadId],
      DEALER_ID: [null],
      LEAD_SOURCE: [''],
      LEAD_PUBLISHER: [''],
      LEAD_CAMPAIGN: [''],
      //Personal Details
      ENQ_TYPE:['', Validators.required],
      TITLE: ['', Validators.required],
      FIRST_NAME: [null, Validators.required],
      LAST_NAME: [null, Validators.required],
      MOBILE_NO: [null, Validators.required],
      ALTERNATE_MOBILE_NO: [null],
      EMAIL_ID: [null, [Validators.required,Validators.email]],
      //Vechical Detail
      CATEGORY_ID:['', Validators.required],
      MAKE_ID: [''],
      MODEL_ID: [''],
      OCCUPATION: [null],
      Finance_required:[null],
      PRICE_RANGE: [null],
      SALES_PERSON: [null],
      Exchange:[null],
      EXISTING_MAKE:[''],
      EXISTING_MODEL:[''],
      //Location Detail
      WOULDYOUMANTBUYBACK:[null],
      VEHCHEL_DEMO_REQUIRED: [null],
      ENQUIRY_ID: [''],
      CLIENT_ADDRESS: [null],
      CLIENT_PINCODE: [null],
      ENQ_REMARKS: [null],
      DOB:[null],
      PREFERRED_LAGUAGE: [''],
      CREATED_BY: [null]
    });
  }
  get f() { return this._Form.controls; }
  async pageLoad(){
    this._Form.controls["CREATED_BY"].setValue(localStorage.getItem("USER_ID"))
  }
  async getLeaddtl(LEAD_ID:number) {
    let data= await this._dbService.GetLeadDetails(LEAD_ID,"LeadID","",null,null);
    JSON.stringify(data);
    var datePipe = new DatePipe("en-US");
    if (data != null) {
      if(data[0]["ISLead"]==1){
        this._Form.controls["Finance_required"].setValue("false");
        this._Form.controls["WOULDYOUMANTBUYBACK"].setValue("false");
        this._Form.controls["Exchange"].setValue("false");
        this._Form.controls["VEHCHEL_DEMO_REQUIRED"].setValue("false");
        for (const field in this._Form.controls) {
          if(field!="VEHCHEL_DEMO_REQUIRED" && field!="MODEL_ID" && field!="Finance_required" && field!="Exchange" && field!="WOULDYOUMANTBUYBACK" ) {
            if(data[0][field]!=null){
              this._Form.controls[field].setValue(data[0][field]);
            }
          }
          if(field=="MODEL_ID"){
            //debugger;
            if(data[0]["MAKE_ID"]!=null){
            this.getModel(data[0]["MAKE_ID"],"NEW")
            }
            if(data[0]["MODEL_ID"]==null){
              this._Form.controls[field].setValue('');
            }
            else{
              this._Form.controls[field].setValue(data[0]["MODEL_ID"]);
            }
          }
          if(field=="EXISTING_MODEL"){
            if(data[0]["EXISTING_MAKE"]!=null){
            this.getModel(data[0]["EXISTING_MAKE"],"OLD")
            }
            if(data[0]["EXISTING_MODEL"]==null){
              this._Form.controls[field].setValue('');
            }
            else{
              this._Form.controls[field].setValue(data[0]["EXISTING_MODEL"]);
            }
          }
        }
        if(data[0]["Finance_required"]!=null){
          if(data[0]["Finance_required"].replace(/\s/g, "")=="true"){
            this._Form.controls["Finance_required"].setValue("true");
          }
        }
        if(data[0]["WOULDYOUMANTBUYBACK"]!=null){
          if(data[0]["WOULDYOUMANTBUYBACK"].replace(/\s/g, "")=="true"){
            this._Form.controls["WOULDYOUMANTBUYBACK"].setValue("true");
          }
        }
        if(data[0]["Exchange"]!=null){
          if(data[0]["Exchange"].replace(/\s/g, "")=="true"){
            this._Form.controls["Exchange"].setValue("true");
          }
        }
        if(data[0]["VEHCHEL_DEMO_REQUIRED"]!=null){
          if(data[0]["VEHCHEL_DEMO_REQUIRED"].replace(/\s/g, "")=="true"){
            this._Form.controls["VEHCHEL_DEMO_REQUIRED"].setValue("true");
          }
        }
        //this._Form.controls["DOB"].setValue(datePipe.transform(data[0]["DOB"], 'dd/MM/yyyy'))
      }
      else{
        for (const field in this._Form.controls) {
          if(field!="TITLE" && field!="SALES_PERSON" && field!="PREFERRED_LAGUAGE"
          && field!="MAKE_ID" && field!="MODEL_ID" && field!="ENQUIRY_ID"
          && field!="EXISTING_MAKE" && field!="EXISTING_MODEL")
          this._Form.controls[field].setValue(data[0][field]);
        }
      }

      this.MobileNo = data[0]["MOBILE_NO"];
      this.LeadName = data[0]["FIRST_NAME"];
      this.LeadDateTime = data[0]["LEAD_CREATED_DATE"];
      this.LeadCode = data[0]["LEAD_ID"];
      this.current_Dealer=data[0]["DEALER_ID"];this.current_LeadId=data[0]["LEAD_ID"];
      this._isgettrns=true;
      //this.onLeadHistory(data[0]["LEAD_ID"],data[0]["DEALER_ID"],Number(localStorage.getItem("USER_ID")))
      console.log(data);
      // this._Form.controls["ENQ_TYPE"].setValue(data[0]["6"]);
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }

  async getEnquiryStatus() {
    let data = await this._dbService.GetDropDownDetails("ENQUIRY", "",Number(localStorage.getItem("DEALER_ID"))  );
    JSON.stringify(data);
    if (data != null) {
      this._EnquiryStatusList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getCategory() {
    let data = await this._dbService.GetDropDownDetails("CATEGORY", "",Number(localStorage.getItem("DEALER_ID"))  );
    JSON.stringify(data);
    if (data != null) {
      this._CategoryList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getSalesMan() {
    let data = await this._dbService.GetDropDownDetails("SALESMAN", "",Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      this._SalesManList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getCampaign() {
    this._CampaignList=[];
    let data = await this._dbService.GetDropDownDetails("LEAD_CAMPAING",null,Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      this._CampaignList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getTitle() {
    let data = await this._dbService.GetDropDownDetails("TITLE", "",Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      this._TitleList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getLanguage() {
    let data = await this._dbService.GetDropDownDetails("LANGUAGE", "",Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      this._LanguageList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getMake() {
    let data = await this._dbService.GetDropDownDetails("MAKE", "",Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      this._MakeList = data;
      this._OLD_MakeList=data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getModel(MakeId :number,type:string) {
    let data = await this._dbService.GetDropDownDetails("MODEL", "MAKE_ID="+MakeId,Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      if(type=="NEW"){
        this._ModelList = data;
      }
      if(type=="OLD"){
        this._OLD_ModelList = data;
      }
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }

  public async onSubmit() {
    this.submitted = true;
    if (this._Form.invalid) {
      return;
    }
    try {
      let data = await this._dbService.PostLeadDetails(this._Form.value);
      JSON.stringify(data);
      if (data != null) {
        this._Form.controls["LEAD_DETAILS_ID"].setValue(data);
        this.toastr.error("Lead details not updated successfully!",'Lead Details');
      }
      else {
        this.toastr.success("Lead details updated successfully!",'Lead Details');
      }
    }
    catch(error){

    }
  }


  public async onReset() {
    this.submitted = false;
  }
  async onCloseModal() {
    // this.modalService.dismissAll();
  }
}
