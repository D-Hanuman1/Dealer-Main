import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { environment } from '@env/environment';
import { AdminLayoutComponent } from '../theme/admin-layout/admin-layout.component';
import { AuthLayoutComponent } from '../theme/auth-layout/auth-layout.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './sessions/register/register.component';
import { Error403Component } from './sessions/403.component';
import { Error404Component } from './sessions/404.component';
import { Error500Component } from './sessions/500.component';
import { AuthGuard } from '@core/authentication/auth.guard';
import { LeadCallingModule } from 'app/pages/lead-calling/lead-calling.module';
import { LoginModule } from './login/login.module';
import { AppReminderModule } from 'app/pages/app-calling/app-calling.module';
import { NotVisitedModule } from 'app/pages/not-vis-calling/not-vis-calling.module';
import { OldLeadModule } from 'app/pages/old-lead-calling/old-lead-calling.module';
import { AdvSearchModule } from 'app/pages/advsearch/advsearch.module';
import { TodayModule } from 'app/pages/todaytask/todaytask.module';
// import { LeadAppDetailComponent } from 'app/pages/lead-app-detail/lead-app-detail.component';
import { LeadAppDetailModule } from 'app/pages/lead-app-detail/lead-app-detail.module';
import { ViewquotComponent } from 'app/pages/lead-app-detail/viewquot/viewquot.component';


const routes: Routes = [
  {
    path: '',
    component: AdminLayoutComponent,
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent },
      { path: '403', component: Error403Component },
      { path: '404', component: Error404Component },
      { path: '500', component: Error500Component },
      {
        path: 'lead-calling',
        loadChildren: () => LeadCallingModule
      },
      {
        path: 'app-reminder',
        loadChildren: () => AppReminderModule
      },
      {
        path: 'not-vis-calling',
        loadChildren: () => NotVisitedModule
      },
      {
        path: 'old-lead-calling',
        loadChildren: () => OldLeadModule
      },
      {
        path: 'adv-search',
        loadChildren: () => AdvSearchModule
      },
      {
        path: 'todaytask',
        loadChildren: () => TodayModule
      },
      {
        path: 'todaytaskdtl',
        loadChildren: () => LeadAppDetailModule },
      {
        path: 'todaytaskdtl',
        loadChildren: () => LeadAppDetailModule },
        {
          path: 'viewQuty',
          component: ViewquotComponent }
    ],
  },
  {
    path: 'auth',
    component: AuthLayoutComponent,
    children: [
      { path: 'login', component: LoginComponent },
      { path: 'register', component: RegisterComponent },
    ],
  },
  {
   path: 'login', loadChildren: () => LoginModule
  },
  { path: '**', redirectTo: 'dashboard' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      useHash: environment.useHash,
      relativeLinkResolution: 'legacy',
    }),
  ],
  exports: [RouterModule],
})
export class RoutesRoutingModule {}
