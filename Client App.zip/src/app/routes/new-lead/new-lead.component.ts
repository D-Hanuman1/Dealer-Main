import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators,NgForm } from '@angular/forms';
import { MatDialogClose, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSelectChange } from '@angular/material/select';
// import { MtxDialogComponent } from '@ng-matero/extensions/dialog';
import { dbLeadCallingService } from 'app/services/dbLeadCalling';
import { ToastrService } from 'ngx-toastr';
declare var $:any;
@Component({
  selector: 'app-new-lead',
  templateUrl: './new-lead.component.html',
  styleUrls: ['./new-lead.component.css']
})
export class NewLeadComponent implements OnInit {
  closeResult: string;public current_LeadId:string;isRefbyMobile:boolean=false;
  submitted = false;_dataList:any;_isdataList:boolean=false;
  _Form: FormGroup;isSpinnerVisible: boolean = false;
  _CategoryList: any = []; _CampaignList: any = [];

  constructor(private fb: FormBuilder,private _dbService:dbLeadCallingService,private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public searchInfo: {SearchType: string,SearchValue:string}) { }
  async ngOnInit(): Promise<void> {
    this.isSpinnerVisible=true;
    await this.formBuild();
    await this.pageLoad();
    await this.getCategory();
    await this.getCampaign();
    this.isSpinnerVisible=false;
  }
  formBuild()
  {
    this._Form = this.fb.group({
      LEAD_ID: [null],
      DEALER_ID: [null],
      CATEGORY_ID: ['', Validators.required],
      CAMPAIGN_ID: ['', Validators.required],
      LEAD_REMARKS: ['', Validators.required],
      LEAD_EMAIL: ['', [Validators.required, Validators.email]],
      LEAD_NAME: ['', Validators.required],
      MOBILE_NO: ['', Validators.required],
      REF_BY_MOBILE: [''],
      SOURCE_ID: [null],
      PUBLISHER_ID: [null],
      CREATED_BY: [null]
    });
    if(this.searchInfo.SearchType=="LeadMobile"){
      this._Form.controls["MOBILE_NO"].setValue(this.searchInfo.SearchValue)
    }
    else if(this.searchInfo.SearchType=="LeadName"){
      this._Form.controls["LEAD_NAME"].setValue(this.searchInfo.SearchValue)
    }
    else if(this.searchInfo.SearchType=="LeadEmail"){
      this._Form.controls["LEAD_EMAIL"].setValue(this.searchInfo.SearchValue)
    }
  }
  get f() { return this._Form.controls; }
  async pageLoad() {
    this._Form.controls["DEALER_ID"].setValue(localStorage.getItem("DEALER_ID"))
    this._Form.controls["CREATED_BY"].setValue(localStorage.getItem("USER_ID"))
  }
  async getCategory() {
    let data = await this._dbService.GetDropDownDetails("CATEGORY", "", Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      this._CategoryList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  async getCampaign() {
    this._CampaignList = [];
    let data = await this._dbService.GetDropDownDetails("LEAD_CAMPAING", null, Number(localStorage.getItem("DEALER_ID")));
    JSON.stringify(data);
    if (data != null) {
      this._CampaignList = data;
    }
    else {
      console.log(data["Status"] + '----->' + data["Message"]);
    }
  }
  public async onSubmit() {
    this.submitted = true;
    if (this._Form.invalid) {
      return;
    }
    try {
      let data = await this._dbService.PostNewLead(this._Form.value);
      JSON.stringify(data);
      if (data != null) {
        this.toastr.error("Lead not created successfully!", 'New Lead');
        // this.closeDialog
      }
      else {
        this.toastr.success("Lead created successfully!", 'New Lead');
        //this.onReset();
      }
    }
    catch (error) {

    }
  }

  // closeDialog(){
  //   this.dialog.close();
  // }

  public async onReset() {
    this.submitted = false;
    this._Form.reset();
  }
  async onEnquiryChange(event:MatSelectChange) {
    let enquiryValue = event.source.triggerValue;
    const REF_BY_MOBILE = this._Form.get('REF_BY_MOBILE');
    if (enquiryValue == "Ref") {
      REF_BY_MOBILE.setValidators([Validators.required]);
      this.isRefbyMobile=true;
    }
    else {
      REF_BY_MOBILE.setValidators(null);
      this.isRefbyMobile=false;
    }
    REF_BY_MOBILE.updateValueAndValidity();
  }



}
// private dialog: MatDialogRef<MtxDialogComponent>,
