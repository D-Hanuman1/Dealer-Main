import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators,NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { dbLoginService } from 'app/services/dbLogin.services';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  submitted = false;
  _Form: FormGroup;
  constructor(private fb: FormBuilder,private _dbService:dbLoginService,private router:Router,
    private toastr: ToastrService) { }

  ngOnInit(): void {
    this.formBuild();
  }
  formBuild()
  {
    this._Form = this.fb.group({
      username:['',Validators.required],
      password:['',Validators.required]
    });
  }
  get f() { return this._Form.controls; }
  async onSubmit() {
    this.submitted = true;
    if (this._Form.invalid) {
      return;
    }

    let data= await this._dbService.GetLogin(this._Form.value);
    JSON.stringify(data);
    console.log(data);

    if(data.length !=0){
      this.toastr.success("Authorized user",'Login');
      localStorage.setItem("USER_ID",data[0]["USER_ID"]);
      localStorage.setItem("USER_NAME",data[0]["USER_NAME"]);
      localStorage.setItem("DEALER_ID",data[0]["DEALER_ID"]);

      this.router.navigate(['/leadcalling'])
    }
    else{
      // console.log(data["Status"]+'----->'+data["Message"]);
      this.toastr.error("Unauthorized user / Invalid password",'Login');
    }
  }

}
