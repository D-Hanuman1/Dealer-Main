import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login.component';

const COMPONENTS: any[] = [
  LoginComponent,
];
const routes: Routes = [
  { path: '', component: LoginComponent }
];
@NgModule({
  imports: [SharedModule,RouterModule.forChild(routes)],
  declarations: [...COMPONENTS,],
})
export class LoginModule {}
