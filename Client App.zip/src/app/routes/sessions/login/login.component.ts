import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '@core/authentication/auth.service';
import { HttpErrorResponse } from '@angular/common/http';
import { filter } from 'rxjs/operators';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
})
export class LoginComponent implements OnInit {
  isSubmitting = false;

  loginForm!: FormGroup;

  constructor(private fb: FormBuilder, private router: Router, private auth: AuthService) {}

  ngOnInit() {
    // this.loginForm = this.fb.group({
    //   username: ['', [Validators.required]],
    //   password: ['', [Validators.required]],
    //   remember_me: [false],
    // });
  }

  get username() {
    //alert("h1");
    return this.loginForm.get('username');
  }

  get password() {
    //alert("h2");
    return this.loginForm.get('password');
  }

  get rememberMe() {
    //alert("h3");
    return this.loginForm.get('remember_me');
  }

  login() {
    this.isSubmitting = true;

    this.auth
      .login(this.username?.value, this.password?.value, this.rememberMe?.value)
      .pipe(filter(authenticated => authenticated))
      .subscribe(
        () => this.router.navigateByUrl('/'),
        (errorRes: HttpErrorResponse) => {
          if (errorRes.status === 422) {
            const form = this.loginForm;
            const errors = errorRes.error.errors;
            Object.keys(errors).forEach(key => {
              form.get(key === 'email' ? 'username' : key)?.setErrors({
                remote: errors[key][0],
              });
            });
          }
          this.isSubmitting = false;
        }
      );
  }
}
