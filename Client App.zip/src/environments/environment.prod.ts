export const environment = {
  production: true,
  baseUrl: '',
  useHash: false,
  apibaseUrl:"https://localhost:44386/api/"
};
